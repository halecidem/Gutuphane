﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace BitirmeProjesi
{
    class GenelIslemler
    {
        public bool SQLControl() //Sunucunun açık olduğunu kontrol eden fonksiyon
        {
            bool sunucuDurum = false;
            try
            {
                SqlConnection baglanti = new SqlConnection(@"Server=LAPTOP-J2VV6GEA\SQLEXPRESS;Database=Gutuphane;Trusted_Connection=true;");
                baglanti.Open();
                sunucuDurum = true;
                baglanti.Close();
            }
            catch
            {
                //sunucuDurum = false;
            }
            return sunucuDurum;
        }
            
    }
}
